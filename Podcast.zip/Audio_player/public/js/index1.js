$(window).load(function() {
    setTimeout(function() {
        $('.fly-in').removeClass('hidden');
    }, 700);
});