var  express = require('express')
var      app = express()
//var podcastSearch = require('podcast-search');
var mongoose = require('mongoose')
app.set("view engine", "ejs");
mongoose.connect("mongodb://localhost/trial");

app.use(express.static(__dirname+'/views'))
app.use(express.static(__dirname+'/public'))

var Parser = require('rss-parser');
var parser = new Parser({
  customFields: {
    feed: [
      ['atom:link', 'atomlink'],
      ['itunes:image','image'],
      ['itunes:category','category'],
      ['itunes:explicit','explicit'],
      ['itunes:summary','summary'],
      ['itunes:author','author'],
      ['itunes:owner','owner'],
      ['itunes:new-feed-url','nfurl'],            
      ['itunes:type','type']      
    ],

    item: [
        ['itunes:duration','duration'],
        ['itunes:image','image'],
      ['dc:creator', 'creator'],
    ]
  }
});
var rssSchema = new mongoose.Schema ({
    link: String
})
 
var RSS = mongoose.model("RSSLink", rssSchema);
var item;
var channel= [];
var temp;

RSS.find({}, function(err, allLinks) {
    if (err) {
        console.log(err);
    } else {
        for(let i = 0; i<allLinks.length; i++) {
            parser.parseURL(allLinks[i].link,function(err,feed) {
                if(!err) {    
                                    
                    channel.push(feed);
                    console.log(i);
                    // INTEGRATION OF ANIMATION!!!
                }
            })
        }
                 
    }
})

app.get('/', function(req,res)  {
    res.render("./animation/index1");
})

app.get('/home', function(req,res){
    res.render("index", {channel:channel}); 
})

app.listen('3000', function(err){
    if(err)console.log(err)
    console.log("Server running on port 3000")
})
